# 🦇 Challenge Name: Dark Secrets of Gotham

## 📖 Story

The night is cold over Gotham.  
Rain glistens off the rooftops, and somewhere between the thunder and the sirens, the Bat-Signal cuts through the clouds.  
But tonight, the call isn’t coming from Commissioner Gordon — it’s coming from *you*.  

You’ve intercepted a transmission embedded inside an image of Batman himself — the Dark Knight watching over the city.  
Rumor in the underground says there’s something hidden deep within the digital shadows of this file…  
something only Bruce Wayne could have left behind.  

The image looks ordinary — just another watchful gaze over Gotham — but the metadata whispers otherwise.  

---

## 🦇 Intel

Batman guards the city by night.  
Bruce hides his secrets by day.  
Only those who can see beyond the mask will uncover the truth.

---

## 🧰 Tools You Might Use

- `exiftool` — Inspect metadata and comments  
- `xxd` — View and edit raw hex data  
- `binwalk` — Scan for embedded files  
- `hexdump` — Explore file structure in binary form  
------
<details>
<summary>💡 Hint (click to reveal)</summary>
Try exiftool and look for the metadata.
</details>
