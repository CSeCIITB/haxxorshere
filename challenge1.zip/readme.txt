Challenge 1: Digital Awakening

This would contain the actual challenge files, puzzles, and instructions.

Flag: CTF{welcome_to_the_matrix}