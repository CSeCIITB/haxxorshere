from Crypto.Util.number import *
while True:
    p = getPrime(256)
    q = bin(p)[2:]
    q = q.replace('1', '11')
    q = q.replace('0', '10')
    if isPrime(int(q,2)):
        break

n = p*int(q,2)
FILE = "out.txt"
with open(FILE, "w") as f:
    f.write(str(n))
