Challenge 2: Cipher Nexus

This would contain cryptographic puzzles and encrypted files to decode.

Flag: CTF{crypto_master}