# Create the CSS file content
css_content = '''/* Challenge Matrix - CTF Platform Styles */

* {
    margin: 0;
    padding: 0;
    box-sizing: border-box;
}

:root {
    --neon-green: #00ff41;
    --neon-cyan: #00d4ff;
    --neon-purple: #ff0080;
    --dark-bg: #0a0a0a;
    --card-bg: #1a1a1a;
    --border-color: #333;
    --text-primary: #ffffff;
    --text-secondary: #cccccc;
    --success-color: #00ff41;
    --error-color: #ff0040;
}

body {
    font-family: 'Courier New', monospace;
    background: var(--dark-bg);
    color: var(--text-primary);
    min-height: 100vh;
    overflow-x: hidden;
    position: relative;
}

/* Matrix Rain Effect */
.matrix-rain {
    position: fixed;
    top: 0;
    left: 0;
    width: 100%;
    height: 100%;
    pointer-events: none;
    z-index: -1;
    background: linear-gradient(45deg, 
        rgba(0, 255, 65, 0.02) 0%, 
        rgba(0, 212, 255, 0.02) 50%, 
        rgba(255, 0, 128, 0.02) 100%);
}

.matrix-rain::before {
    content: '';
    position: absolute;
    top: 0;
    left: 0;
    width: 100%;
    height: 100%;
    background-image: 
        radial-gradient(circle at 25% 25%, var(--neon-green) 0%, transparent 50%),
        radial-gradient(circle at 75% 75%, var(--neon-cyan) 0%, transparent 50%);
    opacity: 0.05;
    animation: pulse 4s ease-in-out infinite alternate;
}

@keyframes pulse {
    0% { opacity: 0.05; }
    100% { opacity: 0.1; }
}

/* Header Styles */
.header {
    text-align: center;
    padding: 2rem 0;
    background: rgba(26, 26, 26, 0.8);
    backdrop-filter: blur(10px);
    border-bottom: 2px solid var(--neon-green);
}

.title {
    font-size: 3rem;
    font-weight: bold;
    color: var(--neon-green);
    text-shadow: 0 0 20px var(--neon-green);
    margin-bottom: 1rem;
    position: relative;
}

/* Glitch Effect */
.glitch {
    position: relative;
    animation: glitch 2s infinite;
}

.glitch::before,
.glitch::after {
    content: attr(data-text);
    position: absolute;
    top: 0;
    left: 0;
    width: 100%;
    height: 100%;
}

.glitch::before {
    animation: glitch-1 0.5s infinite;
    color: var(--neon-cyan);
    z-index: -1;
}

.glitch::after {
    animation: glitch-2 0.5s infinite;
    color: var(--neon-purple);
    z-index: -2;
}

@keyframes glitch {
    0%, 100% { transform: translate(0); }
    20% { transform: translate(-2px, 2px); }
    40% { transform: translate(-2px, -2px); }
    60% { transform: translate(2px, 2px); }
    80% { transform: translate(2px, -2px); }
}

@keyframes glitch-1 {
    0%, 100% { transform: translate(0); }
    20% { transform: translate(2px, -2px); }
    40% { transform: translate(-2px, 2px); }
    60% { transform: translate(2px, 2px); }
    80% { transform: translate(-2px, -2px); }
}

@keyframes glitch-2 {
    0%, 100% { transform: translate(0); }
    20% { transform: translate(-2px, 2px); }
    40% { transform: translate(2px, -2px); }
    60% { transform: translate(-2px, -2px); }
    80% { transform: translate(2px, 2px); }
}

/* Progress Bar */
.progress-bar {
    width: 60%;
    height: 8px;
    background: var(--border-color);
    margin: 1rem auto;
    border-radius: 4px;
    overflow: hidden;
    border: 1px solid var(--neon-green);
}

.progress-fill {
    height: 100%;
    background: linear-gradient(90deg, var(--neon-green), var(--neon-cyan));
    width: 0%;
    transition: width 0.5s ease;
    box-shadow: 0 0 10px var(--neon-green);
}

.progress-text {
    color: var(--text-secondary);
    font-size: 1rem;
    margin-top: 0.5rem;
}

/* Main Container */
.main-container {
    max-width: 1200px;
    margin: 0 auto;
    padding: 2rem;
}

/* Challenges Grid */
.challenges-grid {
    display: grid;
    grid-template-columns: repeat(auto-fit, minmax(350px, 1fr));
    gap: 2rem;
    margin-bottom: 3rem;
}

/* Challenge Card */
.challenge-card {
    background: var(--card-bg);
    border: 2px solid var(--border-color);
    border-radius: 10px;
    padding: 1.5rem;
    transition: all 0.3s ease;
    position: relative;
    overflow: hidden;
    cursor: pointer;
}

.challenge-card::before {
    content: '';
    position: absolute;
    top: 0;
    left: 0;
    right: 0;
    bottom: 0;
    background: linear-gradient(45deg, transparent, rgba(0, 255, 65, 0.1), transparent);
    opacity: 0;
    transition: opacity 0.3s ease;
}

.challenge-card:hover::before {
    opacity: 1;
}

.challenge-card:hover {
    border-color: var(--neon-green);
    box-shadow: 0 0 20px rgba(0, 255, 65, 0.3);
    transform: translateY(-5px);
}

.challenge-card.unlocked {
    border-color: var(--neon-green);
}

.challenge-card.completed {
    border-color: var(--success-color);
    background: rgba(0, 255, 65, 0.1);
}

.challenge-card.locked {
    opacity: 0.5;
    cursor: not-allowed;
}

.challenge-header {
    display: flex;
    justify-content: space-between;
    align-items: center;
    margin-bottom: 1rem;
}

.challenge-title {
    font-size: 1.5rem;
    font-weight: bold;
    color: var(--neon-cyan);
}

.difficulty-badge {
    padding: 0.25rem 0.75rem;
    border-radius: 15px;
    font-size: 0.8rem;
    font-weight: bold;
    text-transform: uppercase;
}

.difficulty-easy {
    background: rgba(0, 255, 65, 0.2);
    color: var(--neon-green);
    border: 1px solid var(--neon-green);
}

.difficulty-medium {
    background: rgba(255, 165, 0, 0.2);
    color: #ffa500;
    border: 1px solid #ffa500;
}

.difficulty-hard {
    background: rgba(255, 0, 64, 0.2);
    color: var(--error-color);
    border: 1px solid var(--error-color);
}

.challenge-description {
    color: var(--text-secondary);
    line-height: 1.6;
    margin-bottom: 1rem;
}

.challenge-status {
    display: flex;
    align-items: center;
    gap: 0.5rem;
    font-size: 0.9rem;
}

.status-icon {
    font-size: 1.2rem;
}

.status-locked { color: var(--border-color); }
.status-unlocked { color: var(--neon-cyan); }
.status-completed { color: var(--success-color); }

/* Modal Styles */
.modal {
    position: fixed;
    top: 0;
    left: 0;
    width: 100%;
    height: 100%;
    z-index: 1000;
    display: flex;
    align-items: center;
    justify-content: center;
    padding: 1rem;
}

.modal.hidden {
    display: none;
}

.modal-content {
    background: var(--card-bg);
    border: 2px solid var(--neon-green);
    border-radius: 15px;
    width: 100%;
    max-width: 600px;
    max-height: 90vh;
    overflow-y: auto;
    position: relative;
    animation: modalSlideIn 0.3s ease;
}

@keyframes modalSlideIn {
    from {
        opacity: 0;
        transform: scale(0.8) translateY(-50px);
    }
    to {
        opacity: 1;
        transform: scale(1) translateY(0);
    }
}

.modal-header {
    display: flex;
    justify-content: space-between;
    align-items: center;
    padding: 1.5rem;
    border-bottom: 1px solid var(--border-color);
}

.modal-header h2 {
    color: var(--neon-cyan);
    font-size: 1.5rem;
}

.close-btn {
    background: none;
    border: none;
    color: var(--text-secondary);
    font-size: 2rem;
    cursor: pointer;
    transition: color 0.3s ease;
}

.close-btn:hover {
    color: var(--neon-purple);
}

.modal-body {
    padding: 1.5rem;
}

.challenge-info {
    margin-bottom: 2rem;
}

.typing-text {
    color: var(--text-secondary);
    line-height: 1.6;
    margin-top: 1rem;
}

/* Form Elements */
.flag-input-section {
    margin-bottom: 2rem;
}

.form-label {
    display: block;
    color: var(--neon-green);
    font-weight: bold;
    margin-bottom: 0.5rem;
}

.form-control {
    width: 100%;
    padding: 0.75rem;
    background: rgba(0, 0, 0, 0.5);
    border: 2px solid var(--border-color);
    border-radius: 5px;
    color: var(--text-primary);
    font-family: 'Courier New', monospace;
    font-size: 1rem;
    transition: all 0.3s ease;
    margin-bottom: 1rem;
}

.form-control:focus {
    outline: none;
    border-color: var(--neon-green);
    box-shadow: 0 0 15px rgba(0, 255, 65, 0.3);
}

.neon-input {
    background: rgba(0, 0, 0, 0.7);
    border: 2px solid var(--neon-cyan);
    box-shadow: 0 0 10px rgba(0, 212, 255, 0.2);
}

/* Buttons */
.btn {
    padding: 0.75rem 1.5rem;
    border: none;
    border-radius: 5px;
    font-family: 'Courier New', monospace;
    font-weight: bold;
    text-transform: uppercase;
    cursor: pointer;
    transition: all 0.3s ease;
    position: relative;
    overflow: hidden;
}

.btn::before {
    content: '';
    position: absolute;
    top: 0;
    left: -100%;
    width: 100%;
    height: 100%;
    background: linear-gradient(90deg, transparent, rgba(255, 255, 255, 0.2), transparent);
    transition: left 0.5s ease;
}

.btn:hover::before {
    left: 100%;
}

.btn-primary {
    background: linear-gradient(45deg, var(--neon-green), var(--neon-cyan));
    color: var(--dark-bg);
    border: 2px solid var(--neon-green);
}

.btn-primary:hover {
    box-shadow: 0 0 20px rgba(0, 255, 65, 0.5);
    transform: translateY(-2px);
}

.btn-secondary {
    background: rgba(0, 212, 255, 0.2);
    color: var(--neon-cyan);
    border: 2px solid var(--neon-cyan);
}

.btn-secondary:hover {
    background: rgba(0, 212, 255, 0.3);
    box-shadow: 0 0 15px rgba(0, 212, 255, 0.3);
}

.btn-download {
    background: rgba(255, 0, 128, 0.2);
    color: var(--neon-purple);
    border: 2px solid var(--neon-purple);
}

.btn-download:hover:not(:disabled) {
    background: rgba(255, 0, 128, 0.3);
    box-shadow: 0 0 15px rgba(255, 0, 128, 0.3);
}

.btn:disabled {
    opacity: 0.5;
    cursor: not-allowed;
    transform: none !important;
    box-shadow: none !important;
}

/* Audio Controls */
.audio-controls {
    display: flex;
    align-items: center;
    justify-content: center;
    gap: 1rem;
    padding: 2rem;
    background: rgba(26, 26, 26, 0.5);
    border-radius: 10px;
    border: 1px solid var(--border-color);
}

.volume-slider {
    width: 150px;
    height: 5px;
    background: var(--border-color);
    outline: none;
    border-radius: 5px;
    -webkit-appearance: none;
}

.volume-slider::-webkit-slider-thumb {
    -webkit-appearance: none;
    width: 15px;
    height: 15px;
    background: var(--neon-green);
    border-radius: 50%;
    cursor: pointer;
    box-shadow: 0 0 10px rgba(0, 255, 65, 0.5);
}

.volume-slider::-moz-range-thumb {
    width: 15px;
    height: 15px;
    background: var(--neon-green);
    border-radius: 50%;
    cursor: pointer;
    border: none;
    box-shadow: 0 0 10px rgba(0, 255, 65, 0.5);
}

/* Feedback Messages */
.feedback-message {
    margin-top: 1rem;
    padding: 0.75rem;
    border-radius: 5px;
    font-weight: bold;
    text-align: center;
    transition: all 0.3s ease;
}

.feedback-success {
    background: rgba(0, 255, 65, 0.2);
    color: var(--success-color);
    border: 1px solid var(--success-color);
}

.feedback-error {
    background: rgba(255, 0, 64, 0.2);
    color: var(--error-color);
    border: 1px solid var(--error-color);
}

/* Overlay */
.overlay {
    position: fixed;
    top: 0;
    left: 0;
    width: 100%;
    height: 100%;
    background: rgba(0, 0, 0, 0.8);
    z-index: 999;
    backdrop-filter: blur(5px);
}

.overlay.hidden {
    display: none;
}

/* Success Effects */
.success-effects {
    position: fixed;
    top: 0;
    left: 0;
    width: 100%;
    height: 100%;
    pointer-events: none;
    z-index: 1001;
    opacity: 0;
    transition: opacity 0.3s ease;
}

.success-effects.active {
    opacity: 1;
}

.particles {
    position: absolute;
    width: 100%;
    height: 100%;
    background: radial-gradient(circle, var(--neon-green) 2px, transparent 2px);
    background-size: 50px 50px;
    animation: particles 1s ease-out;
}

@keyframes particles {
    0% {
        transform: scale(0) rotate(0deg);
        opacity: 1;
    }
    100% {
        transform: scale(2) rotate(360deg);
        opacity: 0;
    }
}

/* Footer */
.footer {
    text-align: center;
    padding: 2rem;
    background: rgba(26, 26, 26, 0.8);
    border-top: 1px solid var(--border-color);
    color: var(--text-secondary);
}

.instructions {
    margin-top: 0.5rem;
    font-size: 0.9rem;
    color: var(--neon-cyan);
}

/* Responsive Design */
@media (max-width: 768px) {
    .title {
        font-size: 2rem;
    }
    
    .challenges-grid {
        grid-template-columns: 1fr;
        gap: 1rem;
    }
    
    .main-container {
        padding: 1rem;
    }
    
    .modal-content {
        margin: 1rem;
        max-width: calc(100% - 2rem);
    }
    
    .audio-controls {
        flex-direction: column;
        gap: 1rem;
    }
    
    .volume-slider {
        width: 200px;
    }
}

@media (max-width: 480px) {
    .title {
        font-size: 1.5rem;
    }
    
    .challenge-header {
        flex-direction: column;
        align-items: flex-start;
        gap: 0.5rem;
    }
    
    .btn {
        width: 100%;
        margin-bottom: 0.5rem;
    }
}

/* Scrollbar Styling */
::-webkit-scrollbar {
    width: 8px;
}

::-webkit-scrollbar-track {
    background: var(--dark-bg);
}

::-webkit-scrollbar-thumb {
    background: var(--neon-green);
    border-radius: 4px;
}

::-webkit-scrollbar-thumb:hover {
    background: var(--neon-cyan);
}'''

# Save CSS file
with open('style.css', 'w', encoding='utf-8') as f:
    f.write(css_content)

print("✅ style.css created successfully")