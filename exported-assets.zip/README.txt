Images Folder
=============

This folder should contain images to make your challenge site look visually appealing.

Suggested images:
- background.jpg - Main background image
- logo.png - Site logo
- challenge-icons/ - Icons for different challenge types
- effects/ - Visual effect images

The CSS is already set up to use background images and visual effects.
You can add images here and reference them in the CSS file.
